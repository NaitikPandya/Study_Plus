import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class QuizView extends StatefulWidget {
  String code;
  QuizView(this.code);
  @override
  _QuizViewState createState() => _QuizViewState(code);
}

class _QuizViewState extends State<QuizView> {
  String code,answer;
  int marks = 0,aTask = 0;
  Stream quiz;
  _QuizViewState(this.code);
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      quiz = Firestore.instance.document("Quiz/$code").collection("quiz").snapshots();
    });
    Firestore.instance.document("Quiz/$code").collection("quiz").snapshots().listen((onData){
      int i = onData.documents.length;
      aTask = i;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Quiz"),
        centerTitle: true,
        backgroundColor: Colors.brown,
        actions: <Widget>[
          FlatButton(
            onPressed:(){ score(context);},
            child: Text("Submit Quiz",style: TextStyle(color: Colors.white,fontSize: 15.0),),
          )
        ],
      ),
      body: _quiz(),
    );
  }
  _quiz()
  {
    if(quiz!= null)
    {
      return StreamBuilder(
          stream: quiz,
          builder: (context , snapshot)
          {
            if(snapshot.data == null){ return Center(child:SpinKitChasingDots(color: Colors.brown)); }
            return ListView.builder(
                padding: const EdgeInsets.all(10),
                shrinkWrap: true,
                itemCount: snapshot.data.documents.length,
                itemBuilder: (BuildContext context, int index)  {
                  return  Card(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(snapshot.data.documents[index].data['Question'],style: TextStyle(fontSize: 25.0),),
                          SizedBox(
                            height: 30,
                          ),
                          GestureDetector(
                            onTap: (){
                              setState(() {
                                answer = snapshot.data.documents[index].data['option1'];
                              });
                              ansCheck(snapshot.data.documents[index].data['option1']);
                            },
                            child: Container(
                              margin: EdgeInsets.only(left: 20.0,right: 20.0),
                              height: 40.0,
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(snapshot.data.documents[index].data['option1'],style: TextStyle(color: Colors.white),),
                              ),
                              decoration: BoxDecoration(
                                  color: Colors.brown,
                                  borderRadius: BorderRadius.circular(30.0)
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          GestureDetector(
                            onTap: ()
                            {
                              ansCheck(snapshot.data.documents[index].data['option2']);
                            },
                            child: Container(
                              margin: EdgeInsets.only(left: 20.0,right: 20.0),
                              height: 40.0,
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(snapshot.data.documents[index].data['option2'],style: TextStyle(color: Colors.white),),
                              ),
                              decoration: BoxDecoration(
                                  color: Colors.brown,
                                  borderRadius: BorderRadius.circular(30.0)
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          GestureDetector(
                            onTap: ()
                            {
                              ansCheck(snapshot.data.documents[index].data['option3']);
                            },
                            child: Container(
                              margin: EdgeInsets.only(left: 20.0,right: 20.0),
                              height: 40.0,
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(snapshot.data.documents[index].data['option3'],style: TextStyle(color: Colors.white),),
                              ),
                              decoration: BoxDecoration(
                                  color: Colors.brown,
                                  borderRadius: BorderRadius.circular(30.0)
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          GestureDetector(
                            onTap: ()
                            {
                              ansCheck(snapshot.data.documents[index].data['option4']);
                            },
                            child: Container(
                              margin: EdgeInsets.only(left: 20.0,right: 20.0),
                              height: 40.0,
                              child: Align(
                                alignment: Alignment.center,
                                child: Text(snapshot.data.documents[index].data['option4'],style: TextStyle(color: Colors.white),),
                              ),
                              decoration: BoxDecoration(
                                  color: Colors.brown,
                                  borderRadius: BorderRadius.circular(30.0)
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 30,
                          ),
                        ],
                      )
                  );
                }
            );}
      );
    }
  }
  ansCheck( String ans )
  {
    if(ans == answer )
      {
        setState(() {
          marks = marks + 1;
        });
      }
  }
   score(context)
  {
    return showDialog(
        context: context,
      child: AlertDialog(
        content: Container(
          height: 500,
          child: Center(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  CircleAvatar(
                    backgroundImage: AssetImage("images/logo.png"),
                    radius: 80,
                  ),
                  Padding(padding: EdgeInsets.only(bottom: 30.0),),
                  Container(
                    height: 160.0,
                    width: 310.0,
                    child: Card(
                      margin: EdgeInsets.all(5.0),
                      color:Colors.brown[100],
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text("Marks You Scored",style: TextStyle(fontSize: 25.0),),
                          Padding(padding: EdgeInsets.only(bottom: 30.0),),
                          Text("${marks.toString()}/${aTask.toString()}",style: TextStyle(fontSize: 25.0))
                        ],
                      ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
        backgroundColor: Colors.brown[100],
        actions: <Widget>[
          FloatingActionButton.extended(
            icon: Icon(Icons.check_circle),
            label: Text("Done"),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            backgroundColor: Colors.brown,
          )
        ],
      )
    );
  }
}
